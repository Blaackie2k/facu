#include <stdio.h>
#include <stdlib.h>

int menores () {
int a , b, r;

printf("Ingrese el primer valor \n");
scanf("%d",&a);
printf("Ingrese el segundo valor \n");
scanf("%d",&b);

    while (a==b) {
        printf("Los valores son iguales, ingrese correctamente\n Ingrese el primer valor \n ");
        scanf("%d",&a);
        printf("Ingrese el segundo valor \n");
        scanf("%d",&b);
    }

    if (a<b) {
        printf("El menor es %d \n",a);
        r=a;
    } else {
        printf("El menor es %d \n",b);
        r=b;
    }

return r;
}

int main()
{
    int resultado, resultado2, resultado3 ;

    resultado = menores () ;
        printf("El resultado es : %d \n",resultado);

    resultado2 = menores ();
        printf("El resultado es : %d \n",resultado);

     resultado3 = menores ();
        printf("El resultado es : %d \n",resultado);


     printf("El menor de la primera vuelta es %d \n",resultado);
     printf("El menor de la segunda vuelta es: %d \n",resultado2);
     printf("El menor de la tercera vuelta es %d \n",resultado3);

    return 0;
}