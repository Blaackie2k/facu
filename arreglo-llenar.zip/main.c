#include <stdio.h>
#include <stdlib.h>
#include<wchar.h>
#include<locale.h>
#include<time.h>


void LLenar(int ArregloA[], int b){
    int i;

    for (i=0;i<b;i++){

        ArregloA[i]=1+rand()%10;
    }

}

int Stop(int ArregloA[], int b,int aleatorio){
    int i,c, indice;

    indice = 10;

    for (i=0;i<5;i++){

        if (i==aleatorio){
            if (ArregloA[i] % 2 != 0){
            indice = i;

            i=6;
        }
        }

    }

    return indice;
}

int main()
{
    int ArregloA[5];
    int i, indice,bandera,aleatorio;

    setlocale(LC_ALL, "");
    srand(time(NULL));

    bandera = 0;

    do{
        for (i=0;i<5;i++){

        ArregloA[i]=0;
    }

    for (i=0;i<5;i++){

        printf("i[%i]=%i\n",i,ArregloA[i]);
    }

    LLenar(ArregloA, 5);

    system("pause");

    for (i=0;i<5;i++){

        printf("i[%i]=%i\n",i,ArregloA[i]);
    }

    system("pause");

    aleatorio = 0+rand()%4;

    indice = Stop(ArregloA, 5,aleatorio);


    if (indice!=10){
         printf("En el indice %d hay un numero impar\n",indice);

         bandera = 1;
    }else{
        printf("En el indice %d no hay ningun impar, se volvera a ejecutar\n",aleatorio);

        bandera = 0;
    }


    }while(bandera!=1);


    return 0;
}