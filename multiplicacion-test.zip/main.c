/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int multiplicacion()
{
    int M, M2;
    printf ("Vamos a hacer una operacion de multiplicacion, por favor digite los numeros a multiplicar: \n");
    printf ("Por favor ingrese el primer numero a multiplicar: \n");
    scanf ("%d", &M);
    printf ("Por favor ingrese el segundo numero a multiplicar: \n");
    scanf ("%d", &M2);
    return M*M2;
    
    
}

int main()
{
    int A;
    A=multiplicacion();
    printf("El resultado de la multiplicacion es: %d", A);
    
  
    return 0;
}
