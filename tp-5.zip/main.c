/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int tablas(int t)
{
     int i;
    int tablasa[11];
    puts("Hola Mundo");
    printf ("Vamos a mostrarle las tablas del numero: %d \n", t);
    for (i=0;i<11;i++){
        tablasa[i]=t*i;
    printf("%d x %d = %d \n",t ,i ,tablasa[i]);
    } 
}
int main()
{
    int result;
    int t;
    printf("Por favor ingrese el numero para que sea mostrado la tabla de dicho numero \n");
    scanf("%d", &t);
    result=tablas(t);
    return 0;
}