#include <stdio.h>
#include <stdlib.h>

int menores () {
int  r;
float a;

printf("Ingrese el primer valor \n");
scanf("%f",&a);

if (a==0){
        r=0;

       }
     if (a>0){
        r=1;

       }
           if (a<0) {

           r=-1;
        }

return r;
}

int main()
{
    int op, resultado;
    op = 0;


    do {

        resultado = menores () ;
        printf("El resultado es : %d \n",resultado);
        printf("Ingrese 0 si desea continuar \nIngrese 1 si desea salir del programa \n");
        scanf("%d",&op);

    } while (op == 0) ;
    
    return 0;
}